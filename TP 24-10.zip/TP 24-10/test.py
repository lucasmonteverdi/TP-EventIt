lista = []
lista.append(["hola", "hola2"])
lista.append(["hola3", "hola4"])
lista.append(["hola5", "hola6"])


#for i in lista:
#    if i[0] == "hola3":
#        print(f"Found, position: {i}")




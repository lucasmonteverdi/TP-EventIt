#                               MÓDULOS Y VARIABLES

from gestion_usuarios import Ciudadano, Administradores
intentos = 0

#                               MÓDULOS Y VARIABLES

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

print("----------------------------------------------------------------------------------------------------")
print("¡Bienvenido al servicio de monitoreo EventIt! Para continuar, por favor regístrese o inicie sesión.")
print("----------------------------------------------------------------------------------------------------")

def inicio_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión.")
    print("[2] Registrarme.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def inicio_sesion_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión como ciudadano.")
    print("[2] Iniciar sesión como administrador.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def registrarse_texto():
    print("-----------------------------------------------")
    print("[1] Registrarse como ciudadano.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def ciudadano_opciones():
    print("-----------------------------------------------")
    print("[1] Enviar solicitud.")
    print("[2] Ver solicitudes.")
    print("[3] Reportar evento.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def admin_opciones():
    print("-----------------------------------------------")
    print("[1] Administradores.")
    print("[2] Eventos.")
    print("[3] Usuarios.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def checkeo():
    print("-----------------------------------------------")
    print("¿Está seguro que desea salir?")
    print("[1] No.")
    print("[2] Sí.")
    print("-----------------------------------------------")

class VolverAlMenu(Exception):
    def __init__(self, msg):
        self.msg = msg

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

inicio_texto()

# El usuario tiene 5 intentos para ingresar las opciones correctamente.
while intentos < 5:

    # Se invita al usuario a seleccionar una opción. Se valida que sea correcta.
    try:
        opcion1 = int(input("Seleccione una de las opciones: "))

        # Opción 'Iniciar sesión'. Se da a elegir si iniciar sesión como ciudadano o como administrador.
        if opcion1 == 1:
            inicio_sesion_texto()

            # El usuario selecciona si iniciar sesión como ciudadano o administrador.
            try:
                opcion2_inicio = int(input("Seleccione una de las opciones: "))

                # Opción 'Iniciar sesión como ciudadano'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 1:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))
                        if Ciudadano().validar_inicio(username, password) == True:
                            ciudadano_opciones()
                        else:
                            raise VolverAlMenu("Inválido.")

                        # Opciones para ciudadanos

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

                    except VolverAlMenu:
                        print("Las credenciales no se encuentran en el sistema. Regrese al menú principal.")
                        inicio_texto()

                # Opción 'Iniciar sesión como administrador'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 2:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))
                        if Administradores().iniciar_sesion(username, password) == True:
                            admin_opciones()
                            try:
                                admin_opcion1 = int(input("Seleccione una de las opciones: "))
                                # Administradores.
                                if admin_opcion1 == 1:
                                    print("[1] Crear administrador.")
                                    print("[2] Ver administradores.")
                                    print("[3] Eliminar administrador.")
                                    try:
                                        admin_admins_opcion1 = int(input("Seleccione una de las opciones: "))
                                        # Crear administrador.
                                        if admin_admins_opcion1 == 1:
                                            admin_cuil = input("Ingrese el CUIL: ")
                                            admin_tel = input("Ingrese el número telefónico: ")
                                            Administradores().crear_admin(admin_cuil, admin_tel)
                                         # Ver administradores.
                                        elif admin_admins_opcion1 == 2:
                                            Administradores().get_info_admins()
                                        # Eliminar administrador.
                                        elif admin_admins_opcion1 == 3:
                                            eliminar_admin_cuil = input("Ingrese el CUIL del administrador a eliminar: ")
                                            Administradores().eliminar_admin(eliminar_admin_cuil)

                                    except ValueError:
                                        intentos += 1
                                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                        inicio_texto()

                                # Eventos.
                                elif admin_opcion1 == 2:
                                    print("[1] Crear evento.")
                                    print("[2] Obtener información de eventos.")
                                    print("[3] Eliminar evento.")
                                    try:
                                        admin_eventos_opcion1 = int(input("Seleccione una de las opciones: "))
                                        # Crear evento.
                                        if admin_eventos_opcion1 == 1:
                                            crear_tipo = input("Ingrese el tipo de evento (Seguridad, salud, etc.): ")
                                            crear_ubicacion = input("Ingrese la ubicación del evento: ")
                                            Administradores().crear_evento(crear_tipo, crear_ubicacion)
                                        # Obtener información de eventos.
                                        elif admin_eventos_opcion1 == 2:
                                            Administradores().get_info_eventos()
                                        # Eliminar evento
                                        elif admin_eventos_opcion1 == 3:
                                            eliminar_id = int(input("Ingrese la ID del evento a eliminar: "))
                                            Administradores().eliminar_evento(eliminar_id)

                                    except ValueError:
                                        intentos += 1
                                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                        inicio_texto()

                                # Ciudadanos.
                                elif admin_opcion1 == 3:
                                    crear_tipo = input("Ingrese el tipo de evento (Seguridad, salud, etc.): ")
                                    crear_ubicacion = input("Ingrese la ubicación del evento: ")
                                    Administradores().crear_evento(crear_tipo, crear_ubicacion)

                                # Salir.
                                elif admin_opcion1 == 0:
                                    pass # Opciones de salir (copiar y pegar)

                            except ValueError:
                                intentos += 1
                                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                inicio_texto()
                        else:
                            raise VolverAlMenu("Inválido.")

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

                    except VolverAlMenu:
                        print("Las credenciales no se encuentran en el sistema. Regrese al menú principal.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Registrarme'.
        if opcion1 == 2:
            registrarse_texto()
            try:
                opcion2_registro = int(input("Seleccione una de las opciones: "))

                # Opción 'Registrame como ciudadano'. Se solicita CUIL y número de teléfono, y se llama al método 'crear_usuario()'.
                if opcion2_registro == 1:
                    try:
                        ciud_cuil = input("Ingrese su CUIL: ")
                        ciud_tel = input("Ingrese su número telefónico: ")
                        Ciudadano().crear_usuario(ciud_cuil, ciud_tel)
                        # Una vez creado el usuario, se vuelve al menú principal.
                        inicio_texto()

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Salir'. Se verifica si el usuario desea salir o no.
        if opcion1 == 0:
            checkeo()
            # Se solicita al usuario elegir 'Sí' o 'No'.
            try:
                opcion1_salir = int(input("Seleccione una de las opciones: "))

                # Opción 'No'.
                if opcion1_salir == 1:
                    raise VolverAlMenu("Regrese al menú principal.")

                # Opción 'Sí'.
                if opcion1_salir == 2:
                    print("¡Gracias por utilizar EventIt!")

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

            # Se lanza una excepción especial para el caso en el que no se quiera salir, para que no cuente como dato erróneo y sume intentos.
            except VolverAlMenu:
                print("Regrese al menú principal.")
                inicio_texto()

    except ValueError:
        intentos += 1
        print("Opción no válida. Intento " + str(intentos) + " de 5.")
        inicio_texto()

# Si se alcanzan los 5 intentos, finaliza la ejecución con este mensaje.
print("Demasiados intentos.")


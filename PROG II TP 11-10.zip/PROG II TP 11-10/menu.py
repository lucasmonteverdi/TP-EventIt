
print("******************************************************************************************************")
print("¡Bienvenido al servicio de monitoreo EventIt! Para continuar, por favor regístrese o inicie sesión.")
print("******************************************************************************************************")

def inicio():
    print("******************************************************************************************************")
    print("[1] Iniciar sesión.")
    print("[2] Registrarme.")
    print("[0] Salir.")
    print("******************************************************************************************************")

inicio()
opcion1 = int(input("Seleccione una de las siguientes opciones: "))

# Función que valida la opción que se eliga en el menú de registrarse/iniciar sesión.
def inicio_opciones(opcion):
    while opcion != 0:

        if opcion == 1:
            username = str(input("Ingrese su nombre de usuario: "))
            password = input("Ingrese su contraseña.")
        elif opcion == 2:
            tel = int(input("Ingrese su número telefónico: "))
            cuil = int(input("Ingrese su CUIL: "))
        else:
            inicio()
            opcion = int(input("Seleccione una de las siguientes opciones: "))

inicio_opciones(opcion1)

# Se verifica si el usuario desea continuar.
def checkeo():
    print("******************************************************************************************************")
    print("¿Está seguro que desea salir?")
    print("[0] No.")
    print("[1] Sí.")
    print("******************************************************************************************************")

# Si se elige 'No', el usuario es redirigido al menú de registrarse/iniciar sesión. Si se elige 'Sí', el programa se "cierra".
if opcion1 == 0:
    checkeo()
    op1_checkeo = int(input("Por favor, seleccione una opción: "))
    if op1_checkeo == 0:
        inicio()
        opcion1_rep = int(input("Seleccione una de las siguientes opciones: "))
        inicio_opciones(opcion1_rep)
    elif op1_checkeo == 1:
        print("¡Gracias por utilizar EventIt!")
    else:
        checkeo()
        op1_checkeo = int(input("Por favor, seleccione una opción: "))
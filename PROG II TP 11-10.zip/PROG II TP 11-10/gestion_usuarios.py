#   Dentro de la clase 'Ciudadano' existirá una lista llamada 'usuarios'. En ella se encuentran todos los usuarios que
#   se hayan registrado en el servicio. En cada posición de la lista habrá una lista con los datos del usuario.
#   La forma en la que se ordenarán los datos es [username, password, cuil, tel].
import random

from gestion_eventos import Eventos

class Ciudadano:

    usuarios = []
    usuarios += ["admin", "admin", 00000000000, 1122334455]
    usuarios_amigos = []
    usuarios_bloqueados = []
    eventos_reportados = []
    intentos = 0

    def __init__(self, dni):
        self.dni = dni

    # Se crea un nuevo usuario y se agrega a la lista de usuarios en el sistema.
    def crear_usuario(self, cuil, tel):
        #La validación de datos se hace en el menu.
        self.usuarios += [cuil, tel]
        return "Usuario creado con éxito."

    # Valida el inicio de sesión de un usuario que ya exista.
    def validar_inicio(self, username, password):
        self.username = username
        self.password = password
        for user in self.usuarios:
            if user[0] == username and user[1] == password:
                return "Inicio de sesión exitoso."
            else:
                return "El usuario no está registrado en el sistema."

    # El usuario que envía la solicitud debe indicar su CUIL y el del destinatario para enviarla. Se indica que ésta fue enviada.
    def enviar_solicitud(self, cuil_origen, cuil_destino):
        self.cuil_origen = cuil_origen
        self.cuil_destino = cuil_destino
        return "Enviada."

    # Se acepta la solicitud y se le indica al usuario que envió la solicitud que fue aceptada.
    def aceptar_solicitud(self):
        self.usuarios_amigos.append([self.cuil_origen, self.cuil_destino])
        return "Aceptado"

    # El usuario al que le llegó la solicitud rechaza la función. Se valida que si el usuario que envió la solicitud tiene más de 5 intentos, se bloquea.
    def rechazar_solicitud(self):
        self.intentos += 1
        if self.intentos == 5:
            self.usuarios_bloqueados.append(self.cuil_origen)
            print("Usuario bloqueado")
        return "Rechazado."

    # Se indican dos parámetros, un tipo y una ubicación, ambos en relación al evento. Dicha información se introduce en una lista que contiene
    # los eventos reportados por ciudadanos. Falta la función de invitar a los amigos.
    def reportar_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion
        self.eventos_reportados.append([tipo, ubicacion])


class Administradores:
    eventos_bdd = []
    administradores = []
    aux_bloqueados = []

    def __init__(self, dni):
        self.dni = dni

    # Se crea un evento indicando un tipo y una ubicación. A cada evento se le asigna una ID única de 4 dígitos para identificarlo.
    def crear_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion
        success = False
        id = random.randint(1000,9999)
        self.eventos_bdd += [tipo, ubicacion, id]
        for evento in self.eventos:
            if evento[2] not in self.eventos:
                self.eventos.append(evento)
                success = True
        return success

    # Método para obtener la identificación de cada evento. Incompleto.
    def get_id(self):
        return self.id

    # Se elimina un evento identificándolo por su ID, una vez validado que ésta existe.
    def eliminar_evento(self, id):
        self.id = id
        cont = 0
        success = False
        for evento in self.eventos:
            if evento[2] == evento[cont]:
                del evento
                success = True
            else:
                cont += 1
        return success

    # Se da de alta un nuevo administrador, y se agrega a la lista de estos si su CUIL no está repetido.
    def crear_admin(self, cuil, tel):
        self.cuil = cuil
        self.tel = tel
        cont = 0
        success = False
        for admin in self.administradores:
            if admin[0] not in self.administradores:
                self.administradores.append(admin)
                success = True
        return success

    # Se elimina un administrador del sistema, si su CUIL existe.
    def eliminar_admin(self, cuil_admin):
        self.cuil_admin = cuil_admin
        for admin in self.administradores:
            if admin[0] not in self.administradores:
                success = False
            else:
                del admin
                success = True
        return success

    # Método que agrega a un ciudadano a la lista de bloqueados según su CUIL.
    def bloquear_ciudadano(self, cuil_ciudadano_b):
        self.cuil_ciudadano_b = cuil_ciudadano_b
        self.aux_bloqueados.append(cuil_ciudadano_b)

    # Método que desbloquea a un ciudadano según su CUIL.
    def desbloquear_ciudadano(self, cuil_ciudadano_d):
        self.cuil_ciudadano_d = cuil_ciudadano_d
        self.aux_bloqueados.remove(cuil_ciudadano_d)

c1 = Ciudadano(897491984)
c2 = Ciudadano(2329894)

c2.crear_usuario(2763547, 9428093234)

c1.crear_usuario(38274983,742983479)
print(c1.enviar_solicitud(94380239,2763547))
print(c1.aceptar_solicitud())
print(c1.rechazar_solicitud())
print(c1.rechazar_solicitud())
print(c1.rechazar_solicitud())
print(c1.rechazar_solicitud())
print(c1.rechazar_solicitud())




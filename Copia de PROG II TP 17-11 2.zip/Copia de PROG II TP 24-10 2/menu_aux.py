#                               MÓDULOS Y VARIABLES

from gestion_usuarios import Ciudadano, Administradores
intentos = 0

#                               MÓDULOS Y VARIABLES

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

print("----------------------------------------------------------------------------------------------------")
print("¡Bienvenido al servicio de monitoreo EventIt! Para continuar, por favor regístrese o inicie sesión.")
print("----------------------------------------------------------------------------------------------------")

def inicio_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión.")
    print("[2] Registrarme.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def inicio_sesion_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión como ciudadano.")
    print("[2] Iniciar sesión como administrador.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def registrarse_texto():
    print("-----------------------------------------------")
    print("[1] Registrarse como ciudadano.")
    print("[2] Registrarse como administrador.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def ciudadano_opciones():
    print("-----------------------------------------------")
    print("[1] Enviar solicitud.")
    print("[2] Ver solicitudes.")
    print("[3] Reportar evento.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def checkeo():
    print("-----------------------------------------------")
    print("¿Está seguro que desea salir?")
    print("[1] No.")
    print("[2] Sí.")
    print("-----------------------------------------------")

class VolverAlMenu(Exception):
    def __init__(self, msg):
        self.msg = msg

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

inicio_texto()

# El usuario tiene 5 intentos para ingresar las opciones correctamente.
while intentos < 5:

    # Se invita al usuario a seleccionar una opción. Se valida que sea correcta.
    try:
        opcion1 = int(input("Seleccione una de las opciones: "))

        # Opción 'Iniciar sesión'. Se da a elegir si iniciar sesión como ciudadano o como administrador.
        if opcion1 == 1:
            inicio_sesion_texto()

            # El usuario selecciona si iniciar sesión como ciudadano o administrador.
            try:
                opcion2_inicio = int(input("Seleccione una de las opciones: "))

                # Opción 'Iniciar sesión como ciudadano'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 1:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))
                        if Ciudadano().validar_inicio(username, password) == True:
                            ciudadano_opciones()

                        # Opciones para ciudadanos

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

                # Opción 'Iniciar sesión como administrador'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 2:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))
                        Administradores().validar_inicio(username, password)

                        # Opciones para administradores

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Registrarme'. Se da a elegir si registrarse como ciudadano o como administrador.
        if opcion1 == 2:
            registrarse_texto()
            try:
                opcion2_registro = int(input("Seleccione una de las opciones: "))

                # Opción 'Registrame como ciudadano'. Se solicita CUIL y número de teléfono, y se llama al método 'crear_usuario()'.
                if opcion2_registro == 1:
                    try:
                        cuil = input("Ingrese su CUIL: ")
                        tel = input("Ingrese su número telefónico: ")
                        Ciudadano().crear_usuario(cuil, tel)
                        # Una vez creado el usuario, se vuelve al menú principal.
                        inicio_texto()

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Salir'. Se verifica si el usuario desea salir o no.
        if opcion1 == 0:
            checkeo()
            # Se solicita al usuario elegir 'Sí' o 'No'.
            try:
                opcion1_salir = int(input("Seleccione una de las opciones: "))

                # Opción 'No'.
                if opcion1_salir == 1:
                    raise VolverAlMenu("Regrese al menú principal.")

                # Opción 'Sí'.
                if opcion1_salir == 2:
                    print("¡Gracias por utilizar EventIt!")

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

            # Se lanza una excepción especial para el caso en el que no se quiera salir, para que no cuente como dato erróneo y sume intentos.
            except VolverAlMenu:
                print("Regrese al menú principal.")
                inicio_texto()

    except ValueError:
        intentos += 1
        print("Opción no válida. Intento " + str(intentos) + " de 5.")
        inicio_texto()

# Si se alcanzan los 5 intentos, finaliza la ejecución con este mensaje.
print("Demasiados intentos.")



#                               COMENTARIOS

# Los administradores pueden registrarse como usuarios normales?
# Si NO --> Crear un usuario 'admin' por defecto para que exista un adminstrador.
# Hacer ABM de administradores una vez iniciada sesión.


import csv, random
import unittest

# La clase usuario actuará como superclase de las subclases 'Ciudadano' y 'Administrador'.
class Usuario:

    # Se crea un nuevo usuario en el sistema, una vez validados sus datos.
    def crear_usuario(self, cuil, tel):
        self.cuil = cuil
        self.tel = tel

        with open('registro_ciudadanos.csv', 'r+') as csv_crear:
            csv_reader = csv.DictReader(csv_crear)
            # next(csv_crear)
            csv_writer = csv.writer(csv_crear)
            try:
                for row in csv_reader:
                    if str(cuil) in row['CUIL'] or str(tel) in row['Telefono']:
                        print("Las credenciales ya se encuentran en el sistema.")
                        return False
            except KeyError:
                username = input("Ingrese su nombre de usuario: ")
                try:
                    while username in row['Username']:
                        username = str(input("Usuario ya registrado. Ingrese uno distinto."))
                except KeyError:
                    password = str(input("Ingrese su contraseña: "))
                    csv_writer.writerow([cuil, tel, username, password])
                    print("Usuario creado con éxito.")
                    return True


    # Se valida el inicio de sesión de un usuario verificando si sus credenciales están en la lista de usuarios.
    def validar_inicio(self, username, password):
        self.username1 = username
        self.password1 = password

        with open('registro_ciudadanos.csv', 'r') as csv_inicio:
            csv_reader = csv.reader(csv_inicio)
            next(csv_inicio)
            try:
                for row in csv_reader:
                    if username in row[2] and password in row[3]:
                        print(f"Inicio de sesión exitoso, {username}.")
                        return True
            except KeyError:
                print("Las credenciales no se encuentran en el sistema.")
                return False

    def test1(self, cuil):
        self.cuil2 = cuil
        with open('registro_ciudadanos.csv') as csv_test1:
            csv_reader = csv.DictReader(csv_test1)
            try:
                for row in csv_reader:
                    if str(cuil) in row['CUIL']:
                        print("Repetido")
                        return False
            except KeyError:
                print("No repetido")
                return True

    def test2(self, tel):
        self.tel2 = tel
        with open('registro_ciudadanos.csv') as csv_test2:
            csv_reader = csv.DictReader(csv_test2)
            try:
                for row in csv_reader:
                    if str(tel) in row['Telefono']:
                        print("Repetido.")
                        return False
            except KeyError:
                print("No repetido.")
                return True

    def print_rows(self):
        with open('registro_ciudadanos.csv') as csv_print:
            csv_reader = csv.DictReader(csv_print)
            for row in csv_reader:
                print(row['CUIL'])
                print(row['Telefono'])

class Ciudadano(Usuario):

    _intentos = 0

    # El usuario que envía la solicitud debe indicar su CUIL y el del destinatario para enviarla. Se indica que ésta fue enviada.
    def enviar_solicitud(self, cuil_origen, cuil_destino):
        self.cuil_origen = cuil_origen
        self.cuil_destino = cuil_destino
        return "Solicitud enviada."

    # Se acepta la solicitud y se le indica al usuario que envió la solicitud que fue aceptada.
    def aceptar_solicitud(self):
        with open('usuarios_amigos.csv', 'r+') as csv_amigos:
            csv_writer = csv.writer(csv_amigos)
            csv_writer.writerow([self.cuil_origen, self.cuil_destino])
        return "Solicitud Aceptada."

    # El usuario al que le llegó la solicitud rechaza la función. Se valida que si el usuario que envió la solicitud tiene más de 5 intentos, se bloquea.
    def rechazar_solicitud(self):
        self._intentos += 1
        with open('usuarios_bloqueados.csv', 'r+') as csv_bloqueados:
            csv_reader = csv.DictReader(csv_bloqueados)
            csv_writer = csv.writer(csv_bloqueados)
            if self._intentos == 5:
                csv_writer.writerow(self.cuil_origen)
                print("Usuario bloqueado")
            return "Solicitud rechazada."

    # Se indican dos parámetros, un tipo y una ubicación, ambos en relación al evento. Dicha información se introduce en una lista que contiene
    # los eventos reportados por ciudadanos. Falta la función de invitar a los amigos.
    def reportar_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion
        with open('eventos_reportados.csv', 'r+') as csv_eventos:
            csv_writer = csv.writer(csv_eventos)
            csv_writer.writerow([tipo, ubicacion])
        return "Evento reportado."


class Administradores(Usuario):

    # Se crea un evento indicando un tipo y una ubicación. A cada evento se le asigna una ID única de 4 dígitos para identificarlo.
    def crear_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion

        id = random.randint(1000,9999)

        with open('eventos.csv', 'r+') as csv_crear_evento:
            csv_reader = csv.reader(csv_crear_evento)
            csv_writer = csv.writer(csv_crear_evento)
            try:
                for evento in csv_reader:
                    while id in evento[2]:
                        id = random.randint(1000, 9999)
            except KeyError:
                csv_writer.writerow([tipo, ubicacion, id])

    # Método para obtener la identificación de cada evento. Incompleto.
    def get_id(self):
        return self.id

    # Se elimina un evento identificándolo por su ID, una vez validado que ésta existe.
    def eliminar_evento(self, id):
        self.id = id
        cont = 0
        with open('eventos.csv', 'r+') as csv_eliminar_evento:
            csv_writer = csv.writer(csv_eliminar_evento)
            for evento in csv_eliminar_evento:
                if id != evento[2]:
                    csv_writer.writerow(evento)
            return True

    # Se da de alta un nuevo administrador, y se agrega a la lista de estos si su CUIL no está repetido.
    def crear_admin(self, cuil, tel):
        self.cuil = cuil
        self.tel = tel
        Usuario().crear_usuario(cuil, tel)

    # Se elimina un administrador del sistema, si su CUIL existe.
    def eliminar_admin(self, cuil_admin):
        self.cuil_admin = cuil_admin

        with open('registro_ciudadanos.csv', 'r+') as csv_eliminar_adm:
            csv_reader = csv.DictReader(csv_eliminar_adm)
            csv_writer = csv.writer(csv_eliminar_adm)
            for user in csv_reader:
                if cuil_admin != user['CUIL']:
                    csv_writer.writerow(user)
            return True


    # Método que agrega a un ciudadano a la lista de bloqueados según su CUIL.
    def bloquear_ciudadano(self, cuil_ciudadano_b):
        self.cuil_ciudadano_b = cuil_ciudadano_b
        with open('usuarios_bloqueados.csv', 'r+') as csv_bloquear:
            csv_writer = csv.writer(csv_bloquear)
            csv_writer.writerow(cuil_ciudadano_b)

    # Método que desbloquea a un ciudadano según su CUIL.
    def desbloquear_ciudadano(self, cuil_ciudadano_d):
        self.cuil_ciudadano_d = cuil_ciudadano_d
        with open('usuarios_bloqueados.csv', 'r+') as csv_desbloquear:
            csv_reader = csv.DictReader(csv_desbloquear)
            csv_writer = csv.writer(csv_desbloquear)
            for bloqueado in csv_reader:
                if cuil_ciudadano_d != bloqueado['CUIL bloqueado']:
                    csv_writer.writerow(bloqueado)


#               COMENTARIOS HASTA AHORA

# Implementar la parte de usar archivos (Monitoreo).


class TestClaseUsuario(unittest.TestCase):
    def test_uno(self):
        self.assertEqual(Usuario().validar_inicio('admin', 'admin'), True)

    def test_dos(self):
        self.assertEqual(Usuario().crear_usuario(7836218746, 874329847923), False)

    #def test_tres(self):
    #    self.assertEqual(Usuario().crear_usuario(398749289,948239847238947), True)

    def test_cuatro(self):
        self.assertEqual(Usuario().test1(82375927987), True)

    def test_cinco(self):
        self.assertEqual(Usuario().test2(1112345678), False)


if __name__ == '__main__':
    unittest.main()


p1 = Usuario()
p1.print_rows()

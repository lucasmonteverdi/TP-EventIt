from gestion_usuarios import Ciudadano, Administradores

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ.

print("----------------------------------------------------------------------------------------------------")
print("¡Bienvenido al servicio de monitoreo EventIt! Para continuar, por favor regístrese o inicie sesión.")
print("----------------------------------------------------------------------------------------------------")

def inicio_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión.")
    print("[2] Registrarme.")
    print("[0] Salir.")
    print("-----------------------------------------------")

inicio_texto()
opcion1 = int(input("Seleccione una de las siguientes opciones: "))

def inicio_sesion_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión como ciudadano.")
    print("[2] Iniciar sesión como administrador.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def registrarse_texto():
    print("-----------------------------------------------")
    print("[1] Registrarse como ciudadano.")
    print("[2] Registrarse como administrador.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def opciones_sistema():
    print("-----------------------------------------------")
    print("[1] Ver solicitudes.")
    print("[2] Reportar evento. ")
    print("-----------------------------------------------")

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ.

#                  FUNCIONES QUE TRABAJAN CON LAS ELECCIONES DEL USUARIO.

def inicio_sesion(opcion):
    while opcion != 0:
        if opcion == 1:
            username_ciud = str(input("Ingrese su nombre de usuario: "))
            password_ciud = str(input("Ingrese su contraseña."))

            try:
                Ciudadano.validar_inicio(username_ciud, password_ciud)
            except Exception:
                pass
            else:
                opciones_sistema()
                opc_sistema1 = int(input("Seleccione una de las opciones: "))


        if opcion == 2:
            username_adm = str(input("Ingrese su nombre de usuario:"))
            password_adm = str(input("Ingrese su contraseña."))
            Administradores.validar_inicio(username_adm, password_adm)
        else:
            inicio_sesion_texto()
            opcion = int(input("Seleccione una de las siguientes opciones:"))

def registrarse(opcion):
    while opcion != 0:
        if opcion == 1:
            cuil_ciud = int(input("Ingrese su CUIL:"))
            tel_ciud = int(input("Ingrese su número telefónico:"))
            Ciudadano.crear_usuario(cuil_ciud, tel_ciud)

        if opcion == 2:
            cuil_adm = int(input("Ingrese su CUIL:"))
            tel_adm = int(input("Ingrese su número telefónico:"))
            Administradores.crear_usuario(cuil_adm, tel_adm)

            # Administradores.validar_inicio(username_adm, password_adm)
        else:
            registrarse_texto()
            opcion = int(input("Seleccione una de las siguientes opciones:"))


# Función que valida la opción que se eliga en el menú de registrarse/iniciar sesión.
def inicio_opciones(opcion):
    while opcion != 0:

        if opcion == 1:
            inicio_sesion_texto()
            opcion2 = int(input("Seleccione una de las siguientes opciones:"))
            inicio_sesion(opcion2)
        elif opcion == 2:
            registrarse_texto()
            opcion2 = int(input("Seleccione una de las siguientes opciones:"))
            registrarse(opcion2)
            # tel = int(input("Ingrese su número telefónico: "))
            # cuil = int(input("Ingrese su CUIL: "))
        else:
            inicio_texto()
            opcion = int(input("Seleccione una de las siguientes opciones: "))

inicio_opciones(opcion1)

# Se verifica si el usuario desea continuar.
def checkeo():
    print("-----------------------------------------------")
    print("¿Está seguro que desea salir?")
    print("[0] No.")
    print("[1] Sí.")
    print("-----------------------------------------------")

#                  FUNCIONES QUE TRABAJAN CON LAS ELECCIONES DEL USUARIO.

#                                   SALIR DEL PROGRAMA.

# Si se elige 'No', el usuario es redirigido al menú de registrarse/iniciar sesión. Si se elige 'Sí', el programa se "cierra".
if opcion1 == 0:
    checkeo()
    op1_checkeo = int(input("Por favor, seleccione una opción: "))
    if op1_checkeo == 0:
        inicio_texto()
        opcion1_rep = int(input("Seleccione una de las siguientes opciones: "))
        inicio_opciones(opcion1_rep)
    elif op1_checkeo == 1:
        print("¡Gracias por utilizar EventIt!")
    else:
        checkeo()
        op1_checkeo = int(input("Por favor, seleccione una opción: "))

#                                   SALIR DEL PROGRAMA.

#                                   COSAS PARA CORREGIR

# Se podria hacer con excepciones el menu?

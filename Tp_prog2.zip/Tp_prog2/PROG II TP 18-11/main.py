import matplotlib.pyplot as plt
from gestion_usuarios import Ciudadano, Administradores

#
# x = [1]
# y = [2]
#
# plt.plot(x, y, 'ro')
# plt.axis([0, 3, 0, 3])
# # plt.step
# plt.legend([x, y], loc=1)
# plt.grid(True)
# plt.show()

import seaborn as sns
import csv, random
import unittest
import pandas as pd
from pandas import DataFrame
import matplotlib.pyplot as plt


class Ciudadano:

    _intentos = 0

    # Se crea un nuevo usuario en el sistema, una vez validados sus datos.
    def crear_usuario(self, cuil, tel):
        self.cuil = cuil
        self.tel = tel
        #success = False

        with open('registro_ciudadanos.csv', 'r+') as csv_registrarse:
            csv_reader = csv.DictReader(csv_registrarse)
            csv_writer = csv.writer(csv_registrarse)
            for row in csv_reader:
                if str(cuil) in row['CUIL'] or str(tel) in row['Telefono']:
                    print("Ya se encuentra registrado")
                    return False
                else:
                    usern = input("Ingrese un nombre de usuario: ")
                    passw = input("Ingrese una contraseña: ")
                    csv_writer.writerow([cuil, tel, usern, passw])
                    print("Usuario creado con éxito.")
                    return True

    # Se valida el inicio de sesión de un usuario verificando si sus credenciales están en la lista de usuarios.
    def validar_inicio(self, username, password):
        self.username1 = username
        self.password1 = password

        with open('registro_ciudadanos.csv', 'r') as csv_inicio:
            csv_reader = csv.DictReader(csv_inicio)
            success = False
            #next(csv_inicio)
            for row in csv_reader:
                if username == row['Username'] and password == row['Password']:
                    # print(f"Inicio de sesión exitoso, {username}.")
                    success = True
        return success

    def get_user_state(self, username, password):

        with open('usuarios_bloqueados.csv', 'r') as csv_bloq:
            csv_reader = csv.DictReader(csv_bloq)
            success = False
            #next(csv_inicio)
            for row in csv_reader:
                if username == row['Username'] and password == row['Password']:
                    # print("Este usuario se encuentra bloqueado!")
                    success = True
        return success

    def get_user_state2(self, username, password):
        with open('usuarios_desbloqueados.csv', 'r') as csv_dsblq:
            csv_reader = csv.DictReader(csv_dsblq)
            success = False
            if Ciudadano().get_user_state(username, password) == True:
                success = True
                for row in csv_reader:
                    if username == row['Username'] and password == row['Password']:
                        success = False
                    else:
                        # print("Este usuario se encuentra bloqueado!")
                        success = True
            else:
                success = False
        return success

    # El usuario que envía la solicitud debe indicar su CUIL y el del destinatario para enviarla. Se indica que ésta fue enviada.
    def enviar_solicitud(self, cuil_origen, cuil_destino):
        self.cuil_origen = cuil_origen
        self.cuil_destino = cuil_destino
        return "Solicitud enviada."

    # Se acepta la solicitud y se le indica al usuario que envió la solicitud que fue aceptada.
    def aceptar_solicitud(self):
        with open('usuarios_amigos.csv', 'r+') as csv_amigos:
            csv_writer = csv.writer(csv_amigos)
            csv_writer.writerow([self.cuil_origen, self.cuil_destino])
        return "Solicitud Aceptada."

    # El usuario al que le llegó la solicitud rechaza la función. Se valida que si el usuario que envió la solicitud tiene más de 5 intentos, se bloquea.
    def rechazar_solicitud(self):
        self._intentos += 1
        with open('usuarios_bloqueados.csv', 'r+') as csv_bloqueados:
            csv_reader = csv.DictReader(csv_bloqueados)
            csv_writer = csv.writer(csv_bloqueados)
            if self._intentos == 5:
                csv_writer.writerow(self.cuil_origen)
                print("Usuario bloqueado")
            return "Solicitud rechazada."

    # Se indican dos parámetros, un tipo y una ubicación, ambos en relación al evento. Dicha información se introduce en una lista que contiene
    # los eventos reportados por ciudadanos. Falta la función de invitar a los amigos.
    def reportar_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion
        with open('eventos_reportados.csv', 'r+') as csv_eventos:
            csv_writer = csv.writer(csv_eventos)
            csv_writer.writerow([tipo, ubicacion])
        return "Evento reportado."

    def reportar_evento2(self, id):
        self.cuil = id

        with open('eventos.csv', 'r') as csv_registro:
            with open('eventos_reportados.csv', 'a') as csv_bloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_bloquear)
                a = "No se encontró ese evento."
                for user in csv_reader:
                    if id == user[2]:
                        csv_writer.writerow(user)
                        a = "Evento reportado!"
                print(a)
                return True

class Administradores(Ciudadano):

    # Se crea un evento indicando un tipo y una ubicación. A cada evento se le asigna una ID única de 4 dígitos para identificarlo.
    def crear_evento(self, tipo, ubicacion):
        self.tipo = tipo
        self.ubicacion = ubicacion

        id = random.randint(1000, 9999)

        with open('eventos.csv', 'r+') as csv_crear_evento:
            csv_reader = csv.reader(csv_crear_evento)
            csv_writer = csv.writer(csv_crear_evento)
            for evento in csv_reader:
                while str(id) in evento[2]:
                    id = random.randint(1000, 9999)
            csv_writer.writerow([tipo, ubicacion, id])

    # Método para obtener la información de cada evento.
    def get_info_eventos(self):
        df = pd.read_csv('eventos.csv')
        print(df.to_string())

    def get_info_eventos2(self):
        Data = pd.read_csv("eventos.csv", usecols = ['x','y'])
        df = DataFrame(Data,columns=['x','y'])
        df.plot(x ='x', y='y', kind = 'scatter')
        plt.grid(True)
        plt.show()

    def get_heatmap(self):
        lugares = pd.read_csv("eventos.csv")
        lugares_df = lugares.pivot("Tipo", "Zona", "Personas")

        sns.heatmap(lugares_df)

        plt.title("Picos Eventos", fontsize=20)
        plt.xlabel("Ubicaciones", fontsize=15)
        plt.ylabel("Tipo", fontsize=15)
        plt.show()

    # Se elimina un evento identificándolo por su ID, una vez validado que ésta existe.
    def eliminar_evento(self, id):
        self.id = id
        with open('eventos.csv', 'r+') as csv_eliminar_evento:
            csv_reader = csv.DictReader(csv_eliminar_evento)
            #next(csv_eliminar_evento)
            csv_writer = csv.writer(csv_eliminar_evento)
            for evento in csv_reader:
                if str(id) != evento['ID']:
                    csv_writer.writerow(evento)
            return True

    def eliminar_evento2(self, id):
        self.cuil = id

        with open('eventos.csv', 'r') as csv_registro:
            with open('eventos_eliminados.csv', 'a') as csv_bloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_bloquear)
                a = "No se encontró ese evento."
                for user in csv_reader:
                    if id == user[4]:
                        csv_writer.writerow(user)
                        a = "Evento eliminado!"
                print(a)
                return True

    def crear_evento3(self, tipo, zona, x, y, cdad):
        self.tipo = tipo
        self.zona = zona
        self.x = x
        self.y = y
        self.cdad = cdad
        id = random.randint(1000, 9999)
        with open('eventos.csv', 'r+') as csv_crear_evento:
            csv_reader = csv.reader(csv_crear_evento)
            next(csv_crear_evento)
            csv_writer = csv.writer(csv_crear_evento)
            for evento in csv_reader:
                while str(id) in evento[4]:
                    id = random.randint(1000, 9999)
            csv_writer.writerow([tipo, zona, x, y, id, cdad])
        print("Evento regsitrado!")

    def top3eventos(self):
        df = pd.read_csv('eventos.csv')
        print(df.nlargest(3, ['Personas']))

    # Se da de alta un nuevo administrador, y se agrega a la lista de estos si su CUIL no está repetido.
    def crear_admin(self, cuil, tel):
        self.cuil = cuil
        self.tel = tel

        with open('registro_administradores.csv', 'r+') as csv_crear:
            csv_reader = csv.DictReader(csv_crear)
            # next(csv_crear)
            csv_writer = csv.writer(csv_crear)
            for row in csv_reader:
                if str(cuil) in row['CUIL'] or str(tel) in row['Telefono']:
                    print("Las credenciales ya se encuentran en el sistema.")
                    return False
                else:
                    username = input("Ingrese su nombre de usuario: ")
                    while username in row['Username']:
                        username = str(input("Usuario ya registrado. Ingrese uno distinto."))
                    password = str(input("Ingrese su contraseña: "))
                    csv_writer.writerow([cuil, tel, username, password])
                    print("Usuario creado con éxito.")
                    return True

    def get_info_admins(self):
        with open('registro_administradores.csv') as csv_info_admins:
            csv_reader = csv.reader(csv_info_admins)
            next(csv_info_admins)
            for admin in csv_reader:
                print(admin)
        return True

    def iniciar_sesion(self, username, password):
        self.username1 = username
        self.password1 = password

        with open('registro_administradores.csv', 'r') as csv_inicio:
            csv_reader = csv.DictReader(csv_inicio)
            success = False
            #next(csv_inicio)
            for row in csv_reader:
                if username == row['Username'] and password == row['Password']:
                    # print(f"Inicio de sesión exitoso, {username}.")
                    success = True
        return success

    # Se elimina un administrador del sistema, si su CUIL existe.
    def eliminar_admin2(self, cuil):
        self.cuil = cuil

        with open('registro_administradores.csv', 'r') as csv_registro:
            with open('Admins_baneados.csv', 'a') as csv_bloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_bloquear)
                a = "No se encontró ese admin."
                for user in csv_reader:
                    if cuil == user[0]:
                        csv_writer.writerow(user)
                        a = "Admin baneado!"
                print(a)
                return True
    # def eliminar_admin(self, cuil_admin):
    #     self.cuil_admin = cuil_admin
    #
    #     with open('registro_administradores.csv', 'r') as csv_eliminar_adm:
    #         with open('Admins_baneados.csv', 'a') as gu:
    #             reader = csv.reader(csv_eliminar_adm)
    #             next(csv_eliminar_adm)
    #             writer = csv.writer(gu)
    #             a = "No se encontró ese Admin."
    #             for user in reader:
    #                 if cuil_admin == user[0]:
    #                     writer.writerow(user)
    #                     a = "Admin baneado!"
    #             print(a)
    #             return True
    def get_admin_state(self, username, password):

        with open('Admins_baneados.csv', 'r') as csv_ban:
            csv_reader = csv.DictReader(csv_ban)
            success = False
            #next(csv_inicio)
            for row in csv_reader:
                if username == row['Username'] and password == row['Password']:
                    # print("Este usuario se encuentra baneado!")
                    success = True
        return success

    # Método que agrega a un ciudadano a la lista de bloqueados según su CUIL.
    def bloquear_ciudadano(self, cuil_ciudadano_b):
        self.cuil_ciudadano_b = cuil_ciudadano_b

        with open('registro_ciudadanos.csv', 'r') as csv_registro:
            with open('usuarios_bloqueados.csv', 'a') as csv_bloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_bloquear)
                a = "No se encontró este usuario."
                for user in csv_reader:
                    if cuil_ciudadano_b == user[0]:
                        csv_writer.writerow(user)
                        a = "Usuario bloqueado!"
                print(a)
                return True


    # Método que desbloquea a un ciudadano según su CUIL.
    # def desbloquear_ciudadano(self, cuil_ciudadano_d):
    #     self.cuil_ciudadano_d = cuil_ciudadano_d
    #     with open('usuarios_bloqueados.csv', 'r+') as csv_desbloquear:
    #         csv_reader = csv.DictReader(csv_desbloquear)
    #         csv_writer = csv.writer(csv_desbloquear)
    #         next(csv_reader)
    #         for bloqueado in csv_reader:
    #             if cuil_ciudadano_d != bloqueado['CUIL bloqueado']:
    #                 csv_writer.writerow(bloqueado)
    #
    def desbloquear_ciudadano2(self, cuil):
        self.cuil = cuil

        with open('usuarios_bloqueados.csv', 'r') as csv_registro:
            with open('usuarios_desbloqueados.csv', 'a') as csv_desbloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_desbloquear)
                a = "No se encontró este usuario."
                for user in csv_reader:
                    if cuil == user[0]:
                        csv_writer.writerow(user)
                        a = "Usuario desbloqueado!"
                print(a)
                return True

class Sensor:
    def reportar_evento(self, id):
        self.cuil = id

        with open('eventos.csv', 'r') as csv_registro:
            with open('eventos_reportados.csv', 'a') as csv_bloquear:
                csv_reader = csv.reader(csv_registro)
                next(csv_registro)
                csv_writer = csv.writer(csv_bloquear)
                a = "Ese evento no existe."
                for user in csv_reader:
                    if id == user[4]:
                        csv_writer.writerow(user)
                        a = "Evento reportado!"
                print(a)
                return True



class TestClaseUsuario(unittest.TestCase):
    def test_uno(self):
        self.assertEqual(Administradores().iniciar_sesion('admin', 'admin'), True)

    def test_dos(self):
        self.assertEqual(Ciudadano().validar_inicio('marselusiano', 'marbaldo3'), False)

    def test_tres(self):
        self.assertEqual(Ciudadano().crear_usuario(3827498273, 423979823749), True)

    # def test_cuatro(self):
    #    self.assertEqual(Ciudadano().test1(10,20))

if __name__ == '__main__':
    unittest.main()

#                           COMENTARIOS
"""
Falta: 
- Función de borrar usuarios, eventos, etc.
- Mapas 
- Tablero de estadísticas
- Sensores
- Asociar contactos con eventos
"""

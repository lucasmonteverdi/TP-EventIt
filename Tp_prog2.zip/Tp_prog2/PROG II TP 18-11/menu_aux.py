#                               MÓDULOS Y VARIABLES

from gestion_usuarios import Ciudadano, Administradores, Sensor
intentos = 0

#                               MÓDULOS Y VARIABLES

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

print("----------------------------------------------------------------------------------------------------")
print("¡Bienvenido al servicio de monitoreo EventIt! Para continuar, por favor regístrese o inicie sesión.")
print("----------------------------------------------------------------------------------------------------")

def inicio_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión.")
    print("[2] Registrarme.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def inicio_sesion_texto():
    print("-----------------------------------------------")
    print("[1] Iniciar sesión como ciudadano.")
    print("[2] Iniciar sesión como administrador.")
    print("[3] Ingresar como sensor.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def registrarse_texto():
    print("-----------------------------------------------")
    print("[1] Registrarse como ciudadano.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def ciudadano_opciones():
    print("-----------------------------------------------")
    print("[1] Enviar solicitud.")
    print("[2] Ver solicitudes.")
    print("[3] Reportar evento.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def admin_opciones():
    print("-----------------------------------------------")
    print("[1] Administradores.")
    print("[2] Eventos.")
    print("[3] Usuarios.")
    print("[0] Salir.")
    print("-----------------------------------------------")

def sensor_opciones():
    print("-----------------------------------------------")
    print("[1] Salud.")
    print("[2] Seguridad.")
    print("[3] Otro.")
    print("-----------------------------------------------")

def checkeo():
    print("-----------------------------------------------")
    print("¿Está seguro que desea salir?")
    print("[1] No.")
    print("[2] Sí.")
    print("-----------------------------------------------")

class VolverAlMenu(Exception):
    def __init__(self, msg):
        self.msg = msg

#                       FUNCIONES QUE EXPRESAN TEXTO EN EL MENÚ Y OTROS.

inicio_texto()

# El usuario tiene 5 intentos para ingresar las opciones correctamente.
while intentos < 5:

    # Se invita al usuario a seleccionar una opción. Se valida que sea correcta.
    try:
        opcion1 = int(input("Seleccione una de las opciones: "))

        # Opción 'Iniciar sesión'. Se da a elegir si iniciar sesión como ciudadano o como administrador.
        if opcion1 == 1:
            inicio_sesion_texto()

            # El usuario selecciona si iniciar sesión como ciudadano o administrador.
            try:
                opcion2_inicio = int(input("Seleccione una de las opciones: "))

                # Opción 'Iniciar sesión como ciudadano'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 1:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))
                        if Ciudadano().validar_inicio(username, password) == True:
                            if Ciudadano().get_user_state2(username, password) == True:
                                print("Este usuario se encuentra bloqueado!")
                                inicio_texto()
                            elif Ciudadano().get_user_state2(username, password) == False:
                                print("Inicio de sesión exitoso!")
                                ciudadano_opciones()
                                try:
                                    ciuda_opcion1 = int(input("Seleccione una de las opciones: "))
                                    #Cuidadanos
                                    if ciuda_opcion1 == 1:
                                        cuil_propio = int(input("Ingrese su CUIL: "))
                                        cuil_amistad = int(input("Ingrese el CUIL del usuario que al que desea enviar solucitud de amistad: "))
                                        Ciudadano().enviar_solicitud(cuil_propio, cuil_amistad)
                                    elif ciuda_opcion1 == 2:
                                        pass
                                    elif ciuda_opcion1 == 3:
                                        try:
                                            id_evento = input("Ingrese el ID del evento que quiere reportar: ")
                                            Ciudadano().reportar_evento2(id_evento)
                                        except ValueError:
                                            intentos += 1
                                            print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                            inicio_texto()
                                except ValueError:
                                    intentos += 1
                                    print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                    inicio_texto()
                        else:
                            raise VolverAlMenu("Inválido.")


                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

                    except VolverAlMenu:
                        print("Las credenciales no se encuentran en el sistema. Regresando al menú principal.")
                        inicio_texto()

                # Opción 'Iniciar sesión como administrador'. Se solicitan nombre de usuario y contraseña y se llama a 'validar_inicio()'.
                if opcion2_inicio == 2:
                    try:
                        username = str(input("Ingrese su nombre de usuario: "))
                        password = str(input("Ingrese su contraseña: "))

                        if Administradores().iniciar_sesion(username, password) == True:
                            if Administradores().get_admin_state(username, password) == True:
                                print("Este usuario se encuentra baneado!")
                                inicio_texto()
                            elif Administradores().get_admin_state(username, password) == False:
                                print("Inicio de sesión exitoso!")
                                admin_opciones()
                                try:
                                    admin_opcion1 = int(input("Seleccione una de las opciones: "))
                                    # Administradores.
                                    if admin_opcion1 == 1:
                                        print("[1] Crear administrador.")
                                        print("[2] Ver administradores.")
                                        print("[3] Eliminar administrador.")
                                        try:
                                            admin_admins_opcion1 = int(input("Seleccione una de las opciones: "))
                                            # Crear administrador.
                                            if admin_admins_opcion1 == 1:
                                                admin_cuil = input("Ingrese el CUIL: ")
                                                admin_tel = input("Ingrese el número telefónico: ")
                                                Administradores().crear_admin(admin_cuil, admin_tel)
                                            # Ver administradores.
                                            elif admin_admins_opcion1 == 2:
                                                Administradores().get_info_admins()
                                            # Eliminar administrador.
                                            elif admin_admins_opcion1 == 3:
                                                eliminar_admin_cuil = input("Ingrese el CUIL del administrador a eliminar: ")
                                                Administradores().eliminar_admin2(eliminar_admin_cuil)

                                        except ValueError:
                                            intentos += 1
                                            print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                            inicio_texto()

                                    # Eventos.
                                    elif admin_opcion1 == 2:
                                        print("-----------------------------------------------")
                                        print("[1] Crear evento.")
                                        print("[2] Obtener información de eventos.")
                                        print("[3] Eliminar evento.")
                                        print("-----------------------------------------------")
                                        try:
                                            admin_eventos_opcion1 = int(input("Seleccione una de las opciones: "))
                                            # Crear evento.
                                            if admin_eventos_opcion1 == 1:
                                                crear_tipo = input("Ingrese el tipo de evento (Seguridad, salud, etc.): ")
                                                crear_zona = input("Ingrese la zona: ")
                                                crear_x = input("Ingrese la ubicación en el eje x: ")
                                                crear_y = input("Ingrese la ubicación en el eje y: ")
                                                crear_cta = input("Ingrese la cantidad de personas a las que afecta el evento: ")
                                                Administradores().crear_evento3(crear_tipo, crear_zona, crear_x, crear_y, crear_cta)

                                            # Obtener información de eventos.
                                            elif admin_eventos_opcion1 == 2:
                                                print("-----------------------------------------------")
                                                print("[1] Ver tabla.")
                                                print("[2] Top 3.")
                                                print("[3] Ver mapa.")
                                                print("[4] Ver indicador de calor de ocurrencia.")
                                                print("-----------------------------------------------")
                                                try:
                                                    eventos_opcion2 = int(input("Seleccione una de las opciones: "))
                                                    if eventos_opcion2 == 1:
                                                        Administradores().get_info_eventos()

                                                    elif eventos_opcion2 == 2:
                                                        Administradores().top3eventos()
                                                    elif eventos_opcion2 == 3:
                                                        Administradores().get_info_eventos2()

                                                    elif eventos_opcion2 == 4:
                                                        Administradores().get_heatmap()

                                                except ValueError:
                                                    intentos += 1
                                                    print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                                    inicio_texto()

                                            # Eliminar evento
                                            elif admin_eventos_opcion1 == 3:
                                                eliminar_id = input("Ingrese la ID del evento a eliminar: ")
                                                Administradores().eliminar_evento2(eliminar_id)

                                        except ValueError:
                                            intentos += 1
                                            print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                            inicio_texto()

                                    # Ciudadanos.
                                    elif admin_opcion1 == 3:
                                        print("-----------------------------------------------")
                                        print("[1] Bloquear usuario.")
                                        print("[2] Desbloquear usuario.")
                                        print("-----------------------------------------------")
                                        try:
                                            admin_ciudadanos_opcion1 = int(input("Seleccione una de las opciones: "))

                                            if admin_ciudadanos_opcion1 == 1:
                                                cuil_ciudadano = input("Ingrese el CUIL del ciudadano a bloquear: ")
                                                Administradores().bloquear_ciudadano(cuil_ciudadano)
                                            elif admin_ciudadanos_opcion1 == 2:
                                                cuil_ciudadano2 = input("Ingrese el CUIL del ciudadano a desbloquear: ")
                                                Administradores().desbloquear_ciudadano2(cuil_ciudadano2)
                                        except ValueError:
                                            intentos += 1
                                            print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                            inicio_texto()

                                    # Salir.
                                    elif admin_opcion1 == 0:
                                        pass # Opciones de salir (copiar y pegar)

                                except ValueError:
                                    intentos += 1
                                    print("Opción no válida. Intento " + str(intentos) + " de 5.")
                                    inicio_texto()
                        else:
                            raise VolverAlMenu("Inválido.")

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

                    except VolverAlMenu:
                        print("Las credenciales no se encuentran en el sistema. Regresando al menú principal.")
                        inicio_texto()
                #Ingresar como sensor
                if opcion2_inicio == 3:
                    sensor_opciones()
                    try:
                        sensor_ops = int(input("Ingrese como que tipo de sensor desea acceder: "))
                        # Sensor Salud
                        if sensor_ops == 1:
                            tipo = "Salud"
                            crear_zona = input("Zona: ")
                            crear_x = input("Ubicación en el eje x: ")
                            crear_y = input("Ubicación en el eje y: ")
                            crear_cta = input("Cantidad de personas a las que afecta el evento: ")
                            Administradores().crear_evento3(tipo, crear_zona, crear_x, crear_y, crear_cta)
                        # Sensor Seguridad
                        elif sensor_ops == 2:
                            tipo = "Seguridad"
                            crear_zona = input("Zona: ")
                            crear_x = input("Ubicación en el eje y: ")
                            crear_y = input("Ubicación en el eje y: ")
                            crear_cta = input("Cantidad de personas a las que afecta el evento: ")
                            Administradores().crear_evento3(tipo, crear_zona, crear_x, crear_y, crear_cta)
                        # Sensor Otro
                        elif sensor_ops == 3:
                            tipo = "Otro"
                            crear_zona = input("Zona: ")
                            crear_x = input("Ubicación en el eje y: ")
                            crear_y = input("Ubicación en el eje y: ")
                            crear_cta = input("Cantidad de personas a las que afecta el evento: ")
                            Administradores().crear_evento3(tipo, crear_zona, crear_x, crear_y, crear_cta)
                    except ValueError:
                        print("Opción no válida.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Registrarme'.
        if opcion1 == 2:
            registrarse_texto()
            try:
                opcion2_registro = int(input("Seleccione una de las opciones: "))

                # Opción 'Registrame como ciudadano'. Se solicita CUIL y número de teléfono, y se llama al método 'crear_usuario()'.
                if opcion2_registro == 1:
                    try:
                        ciud_cuil = input("Ingrese su CUIL: ")
                        ciud_tel = input("Ingrese su número telefónico: ")
                        Ciudadano().crear_usuario(ciud_cuil, ciud_tel)
                        # Una vez creado el usuario, se vuelve al menú principal.
                        inicio_texto()

                    except ValueError:
                        intentos += 1
                        print("Opción no válida. Intento " + str(intentos) + " de 5.")
                        inicio_texto()

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

        # Opción 'Salir'. Se verifica si el usuario desea salir o no.
        if opcion1 == 0:
            checkeo()
            # Se solicita al usuario elegir 'Sí' o 'No'.
            try:
                opcion1_salir = int(input("Seleccione una de las opciones: "))

                # Opción 'No'.
                if opcion1_salir == 1:
                    raise VolverAlMenu("Regrese al menú principal.")

                # Opción 'Sí'.
                if opcion1_salir == 2:
                    print("¡Gracias por utilizar EventIt!")

            except ValueError:
                intentos += 1
                print("Opción no válida. Intento " + str(intentos) + " de 5.")
                inicio_texto()

            # Se lanza una excepción especial para el caso en el que no se quiera salir, para que no cuente como dato erróneo y sume intentos.
            except VolverAlMenu:
                print("Regrese al menú principal.")
                inicio_texto()

    except ValueError:
        intentos += 1
        print("Opción no válida. Intento " + str(intentos) + " de 5.")
        inicio_texto()

# Si se alcanzan los 5 intentos, finaliza la ejecución con este mensaje.
print("Demasiados intentos.")

